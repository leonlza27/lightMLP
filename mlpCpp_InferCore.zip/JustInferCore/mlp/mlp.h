//mlp:仅用作mcu上推理
#ifndef _mlp_static_
#define _mlp_static_

#include "../matrix/matrix_static.h"
#include "activator.h"
#include <stdint.h>

#pragma pack(1)
typedef struct _netLyrConf{
    uint8_t Activetype;       //层激活类型
    qfix dataExtra;         
    matrix_bp existedWeightData;      //已有权重数据(matrix out_dim * in_dim)
    matrix_bp existedBiasData;        //已有偏置数据(matrix out_dim * 1)
}NetLyrConf;
#pragma pack(pop)

class mlpNetRef{
private:
    matrix_bp fullConnDataMid[2];      //全连接层
    NetLyrConf *lyrData;
    uint16_t netLyrCount;

public:
    void init(uint16_t lyrnum,NetLyrConf *netstruct);
    void infer(matrix_bp input);

    inline matrix_bp resu_refAddr(){return fullConnDataMid[(netLyrCount - 1)%2];}
    inline void resu_copyied(matrix_bp output){
        uint16_t ElemSize = fullConnDataMid[(netLyrCount - 1)%2]->cols * fullConnDataMid[(netLyrCount - 1)%2]->rows;
        qfix *outDim = output->data;
        qfix *sourceDim = fullConnDataMid[(netLyrCount - 1)%2]->data;
        for(uint16_t i = 0; i < ElemSize; i++) outDim[i] = sourceDim[i];
    };
};

#endif
